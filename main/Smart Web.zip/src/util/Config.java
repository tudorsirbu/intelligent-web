package util;

public class Config {
	/* Twitter access keys */
	public final String CONSUMER_KEY = "gHCxnRIAapqAfBG5oyt6w";	
	public final String CONSUMER_SECRET = "pisw8haLdrOvmPxyOLkT7xJoEqQkxgei2xrOkhdeJjA";	
	public final String ACCESS_TOKEN = "18540628-4dkbUfF495u9r35CxEfqm5PDorm7e4nraiPFRQCoD";	
	public final String ACCESS_TOKEN_SECRET = "ZgwdueIhOQeZ3ZIt29dKZlWrc4lwcrquQ8JaDCTLeLD1i";
	
	/* Foursquare access keys */
	public final String CLIENT_ID = "JRIYO5DDJ43NBLDNNU3PH1URI0RQ4ZA3TTHEDPFDPYOC2C5L";
	public final String CLIENT_SECRET = "QUIFUD44KU22UDMZUD0FQFRPWH21I2H4Y1J3CSWISUWOMZ1R";
	public final String REDIRECT_URL = "http://www.sheffield.ac.uk";
	public final String FOURSQR_ACCESS_TOKEN = "5PJGTZWVP2QR1BK3LJHVLDYPQVFURSTUA1GGN0V3ZI2NBXIT";
	
	/* RDF stuff */
	public final static String NS = "http://www.smartweb.com/data/#";
	public final static String FOAF_NS = "http://xmlns.com/foaf/0.1/#";
	public final static String GEO_NS = "http://www.w3.org/2003/01/geo/wgs84_pos#";
	public final static String ONTOLOGY_PATH = "ontology.rdf";
	public final static String TRIPLE_STORE_PATH = "triplestore.rdf";
	
}
